# SudokuNilli
Final project ARTI

`ant help` to get directions about running project
To change how this is run, refer to the comments in Main.java.

![alt tag](NilliFace.png)
